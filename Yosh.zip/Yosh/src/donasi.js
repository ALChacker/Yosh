const donasi = () => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ 𝗗𝗢𝗡𝗔𝗦𝗜 𝗕𝗢𝗦𝗤𝗨𝗘 ❉⊰━━✿
┃  
┣➥ *SAWERIA* : https://saweria.co/Newal

┃
┣━━━━━━━━━━━━━━━━━━━━
┃            _*NewalBotツ*_
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi